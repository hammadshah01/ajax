<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- CSS only -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <title>Document</title>
</head>

<body>

    <!-- <script>
        var btnDel = document.getElementById('load_table').children[0].children[1].children[0].children[2].children[0]
        console.log(btnDel);
    </script> -->
    <div class="header">
        <h2> Student Record with Ajax with Add</h2>
    </div>
    <div class="container">
        <table>
            <tr>
                <td>
                    <input type="text" id="fname">
                    <input type="text" id="lname">
                    <input type="submit" value="submit" id="submit">
                </td>
            </tr>

            <tr>
                <td id="load_table">
                </td>
            </tr>

        </table>
    </div>




    <script src="https://code.jquery.com/jquery-3.6.1.js"></script>
    <script type="text/javascript">
        $(document).ready(() => {
            function loadData() {
                $.ajax({
                    url: 'read_data.php',
                    type: 'POST',
                    success: (data) => {
                        var a = $('#load_table').html(data);

                    }

                })

            }
            loadData();



            $('#submit').on('click', (e) => {
                e.preventDefault();
                var fname = $('#fname').val();
                var lname = $('#lname').val();
                if (fname == "" || lname == "") {
                    alert("please enter data first")
                } else {
                    $.ajax({
                        url: 'insert.php',
                        type: 'POST',
                        data: {
                            fname: fname,
                            lname: lname,
                        },
                        success: (data) => {
                            if (data == 1) {
                                loadData();
                            } else {
                                alert("cant save Record");
                            }

                        }
                    })
                }

            });


            $(document).on('click','.del-btn', () => {
              

                var student = $(this).data('id');
                alert(student);
                console.log(student)

                $.ajax({
                    url: 'delete.php',
                    type: "POST",
                    data: {
                        id: student

                    },
                    success: (data) => {

                    }
                })
            })

        });
    </script>



    <!-- <script>
        $(document).ready(() => {
            $('tbody').click('.del-btn', () => {
                let id = $(this).attr('data-id');
                // var id = $(this).data("id");
                //    var $student_id = $(this).$('.del-btn').val();
                console.log(id);
            })

        })
    </script> -->

</body>

</html>