<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- CSS only -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <title>Document</title>
</head>

<body>


    <div class="header">
        <h2> Student Record with Ajax</h2>
    </div>
    <div class="container">
        <table class="table border='0'">
            <tr>
                <td>
                    <input type="button" value="load" id="load_data" class='btn btn-primary'>
                </td>
            </tr>

            <tr>
                <td id="load_table">
                </td>
            </tr>

        </table>
    </div>




    <script src="https://code.jquery.com/jquery-3.6.1.min.js"></script>

    <script>
        $(document).ready(() => {
            $('#load_data').on('click', (e) => {
                $.ajax({
                    url: 'read_data.php',
                    type: 'POST',
                    success: (data) => {
                        $('#load_table').html(data)
                    }


                })
            })
        })
    </script>

</body>

</html>