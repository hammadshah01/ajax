
<?php
 $studentID = $_POST['id'];
$conn = mysqli_connect('localhost', 'root', '', 'test') or die('connection failed');
$sql = "DELETE FROM student WHERE id={$studentID}";
$result = mysqli_query($conn, $sql) or die('query failed');
 
 
 ?>

 