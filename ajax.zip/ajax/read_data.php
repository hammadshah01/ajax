<?php 
$conn = mysqli_connect('localhost','root','','test') or die('connection failed');
$sql="SELECT * FROM student";
$result = mysqli_query($conn,$sql)or die('query failed');
$output = "";
if(mysqli_num_rows($result)>0){
$output = "<table class='table' >
<thead>
<tr>
<th>ID</th>
<th>NAME</th>
<th>DELETE</th>
</tr>
</thead>";
while($row = mysqli_fetch_assoc($result)){
    $output.= "<tbody>
    <tr>
    <td>{$row['id']}</td>
    <td>{$row['first_name']}&nbsp{$row['last_name']}</td>
    <td>
    <button class='btn btn-danger del-btn' value='{$row["id"]}' data-id ='{$row["id"]}'>Delete</button>
    </td>
    </tr>
    </tbody>";
}
 $output.="</table>";
 mysqli_close($conn);
 echo $output;
}else{
    echo"record not found";
}


?>